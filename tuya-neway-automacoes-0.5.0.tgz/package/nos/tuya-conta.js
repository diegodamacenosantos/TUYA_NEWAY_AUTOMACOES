const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const EventEmitter = require('events');
const qrcode = require('qrcode-generator');
const mqtt = require('mqtt');
const api = require('./tuya-api');

const pendentes = new Map();

function normalizarStatus(lista) {
    const saida = {};
    if (Array.isArray(lista)) {
        for (const item of lista) {
            if (item && item.code !== undefined) saida[item.code] = item.value;
        }
    } else if (lista && typeof lista === 'object') {
        Object.assign(saida, lista);
    }
    return saida;
}

function normalizarDispositivo(item) {
    return {
        id: item.id || item.devId,
        nome: item.name || item.id,
        categoria: item.category || '',
        produto: item.productName || item.product_name || '',
        online: item.online !== false,
        suportaLocal: !!(item.supportLocal || item.support_local),
        status: normalizarStatus(item.status),
        mapaDp: {}
    };
}

function decifrarMensagem(senha, texto, t) {
    const chave = Buffer.from(String(senha).slice(8, 24), 'utf8');
    const bruto = Buffer.from(texto, 'base64');
    try {
        const ivLen = bruto.readUInt32BE(0);
        const iv = bruto.subarray(4, 4 + ivLen);
        const tag = bruto.subarray(bruto.length - 16);
        const corpo = bruto.subarray(4 + ivLen, bruto.length - 16);
        const d = crypto.createDecipheriv('aes-128-gcm', chave, iv);
        d.setAuthTag(tag);
        d.setAAD(Buffer.from(String(t), 'utf8'));
        return Buffer.concat([d.update(corpo), d.final()]).toString('utf8');
    } catch (e) {}
    try {
        const d = crypto.createDecipheriv('aes-128-ecb', chave, null);
        return Buffer.concat([d.update(bruto), d.final()]).toString('utf8');
    } catch (e) {}
    return null;
}

module.exports = function (RED) {
    function arquivoSessao(id) {
        return path.join(RED.settings.userDir || '.', 'tuya_sessao_' + id + '.json');
    }

    function TuyaConta(config) {
        RED.nodes.createNode(this, config);
        const node = this;
        node.eventos = new EventEmitter();
        node.eventos.setMaxListeners(0);
        node.dispositivos = new Map();
        node.bruto = [];
        node.estado = 'sem login';
        node.sessao = null;
        node.mq = null;
        node.fechando = false;
        node.nomeCasa = {};

        function guardarBruto(tipo, dado) {
            node.bruto.push({ quando: new Date().toISOString(), tipo, dado });
            if (node.bruto.length > 40) node.bruto.shift();
        }
        node.guardarBruto = guardarBruto;

        function mudarEstado(texto, cor) {
            node.estado = texto;
            node.status({ fill: cor, shape: 'dot', text: texto });
            node.eventos.emit('estado', texto);
        }

        function carregarSessao() {
            let dados = null;
            if (node.credentials && node.credentials.sessao) {
                try {
                    dados = JSON.parse(node.credentials.sessao);
                } catch (e) {}
            }
            try {
                const arq = JSON.parse(fs.readFileSync(arquivoSessao(node.id), 'utf8'));
                if (dados && arq.terminalId === dados.terminalId) dados = arq;
                else if (!dados) dados = arq;
            } catch (e) {}
            return dados;
        }

        function salvarSessao(dados) {
            try {
                fs.writeFileSync(arquivoSessao(node.id), JSON.stringify(dados));
            } catch (e) {
                node.warn('não foi possível salvar a sessão: ' + e.message);
            }
        }

        async function carregarDispositivos() {
            const casas = await node.sessao.casas();
            guardarBruto('casas', casas);
            const lista = Array.isArray(casas.result) ? casas.result : [];
            node.donos = [];
            const novos = new Map();
            for (const casa of lista) {
                node.donos.push(casa.ownerId);
                node.nomeCasa[casa.ownerId] = casa.name;
                const r = await node.sessao.dispositivosDaCasa(casa.ownerId);
                guardarBruto('dispositivos ' + casa.name, r);
                if (Array.isArray(r.result)) {
                    for (const item of r.result) {
                        const d = normalizarDispositivo(item);
                        if (!d.id) continue;
                        d.casa = casa.name;
                        const antigo = node.dispositivos.get(d.id);
                        if (antigo) d.mapaDp = antigo.mapaDp;
                        novos.set(d.id, d);
                    }
                }
            }
            node.dispositivos = novos;
        }

        async function carregarMapaDp(d) {
            try {
                const r = await node.sessao.requisitar('GET', '/v1.0/m/life/devices/' + d.id + '/status');
                guardarBruto('estrategia ' + d.id, r);
                const lista = r.result && (r.result.dpStatusRelationDTOS || r.result.dp_status_relation_dtos);
                if (Array.isArray(lista)) {
                    for (const x of lista) {
                        const dp = x.dpId !== undefined ? x.dpId : x.dp_id;
                        const codigo = x.statusCode || x.status_code || x.dpCode || x.code;
                        if (dp !== undefined && codigo) d.mapaDp[String(dp)] = codigo;
                    }
                }
            } catch (e) {
                guardarBruto('erro estrategia ' + d.id, e.message);
            }
        }

        function aplicarStatus(devId, lista) {
            const d = node.dispositivos.get(devId);
            if (!d || !Array.isArray(lista)) return;
            const mudancas = [];
            for (const item of lista) {
                let codigo = item.code;
                if (!codigo && item.dpId !== undefined) codigo = d.mapaDp[String(item.dpId)];
                if (!codigo) continue;
                d.status[codigo] = item.value;
                mudancas.push({ code: codigo, value: item.value });
            }
            if (mudancas.length) node.eventos.emit('status', devId, mudancas);
        }

        function tratarMensagem(topico, buf) {
            let msg;
            try {
                msg = JSON.parse(buf.toString('utf8'));
            } catch (e) {
                guardarBruto('mq ilegivel ' + topico, buf.toString('utf8').slice(0, 300));
                return;
            }
            let dado = msg.data;
            if (typeof dado === 'string') {
                const claro = decifrarMensagem(node.mqSenha, dado, msg.t);
                if (claro !== null) {
                    try {
                        dado = JSON.parse(claro);
                    } catch (e) {
                        dado = claro;
                    }
                } else {
                    try {
                        dado = JSON.parse(dado);
                    } catch (e) {}
                }
            }
            guardarBruto('mq ' + topico, { protocol: msg.protocol, data: dado });
            if (!dado || typeof dado !== 'object') return;
            if (msg.protocol === 4) {
                aplicarStatus(dado.devId, dado.status);
            } else if (msg.protocol === 20) {
                const d = node.dispositivos.get(dado.devId);
                if (d && (dado.bizCode === 'online' || dado.bizCode === 'offline')) {
                    d.online = dado.bizCode === 'online';
                    node.eventos.emit('online', dado.devId, d.online);
                }
            }
        }

        async function conectarMq() {
            if (node.fechando) return;
            const c = await node.sessao.configMq();
            guardarBruto('config mq', Object.assign({}, c, {
                result: c.result && Object.assign({}, c.result, { password: '***' })
            }));
            if (!c.success) throw new Error('config mq: ' + JSON.stringify(c).slice(0, 200));
            const r = c.result;
            node.mqSenha = r.password;
            const cliente = mqtt.connect(r.url, {
                clientId: r.clientId,
                username: r.username,
                password: r.password,
                reconnectPeriod: 0
            });
            node.mq = cliente;
            cliente.on('connect', () => {
                const topicos = [];
                const dono = r.topic && r.topic.ownerId && r.topic.ownerId.sub;
                const disp = r.topic && r.topic.devId && r.topic.devId.sub;
                if (dono) for (const o of node.donos || []) topicos.push(dono.replace('{ownerId}', o));
                if (disp) {
                    for (const d of node.dispositivos.values()) {
                        topicos.push(disp.replace('{devId}', d.id) + (d.suportaLocal ? '/pen' : '/sta'));
                    }
                }
                guardarBruto('assinando', topicos);
                for (const t of topicos) cliente.subscribe(t);
                mudarEstado('online (' + node.dispositivos.size + ' disp.)', 'green');
            });
            cliente.on('message', tratarMensagem);
            cliente.on('error', (e) => guardarBruto('erro mq', e.message));
            cliente.on('close', () => {
                if (node.mq !== cliente) return;
                node.mq = null;
                if (node.fechando) return;
                mudarEstado('mq caiu, reconectando', 'yellow');
                agendarMq(10000);
            });
            const renovar = Math.max((Number(r.expireTime) || 3600) - 60, 60) * 1000;
            node.timerRenovar = setTimeout(() => {
                if (node.mq) node.mq.end(true);
            }, renovar);
        }

        function agendarMq(ms) {
            clearTimeout(node.timerMq);
            clearTimeout(node.timerRenovar);
            if (node.fechando) return;
            node.timerMq = setTimeout(async () => {
                try {
                    await conectarMq();
                } catch (e) {
                    guardarBruto('erro conectar mq', e.message);
                    mudarEstado('erro mq: ' + e.message.slice(0, 40), 'red');
                    agendarMq(30000);
                }
            }, ms);
        }

        async function iniciar() {
            const dados = carregarSessao();
            if (!dados) {
                mudarEstado('sem login', 'red');
                return;
            }
            node.sessao = new api.Sessao(dados);
            node.sessao.aoRenovar = salvarSessao;
            salvarSessao(node.sessao.exportar());
            try {
                mudarEstado('carregando', 'yellow');
                await carregarDispositivos();
                for (const d of node.dispositivos.values()) {
                    if (d.suportaLocal) await carregarMapaDp(d);
                }
                node.eventos.emit('dispositivos');
                agendarMq(100);
            } catch (e) {
                guardarBruto('erro iniciar', e.message);
                mudarEstado('erro: ' + e.message.slice(0, 40), 'red');
                node.error(e.message);
            }
        }

        node.comando = async function (devId, comandos) {
            if (!node.sessao) throw new Error('sem login');
            const r = await node.sessao.comando(devId, comandos);
            guardarBruto('comando ' + devId, { enviado: comandos, resposta: r });
            if (!r.success) throw new Error('recusado: ' + (r.msg || JSON.stringify(r).slice(0, 120)));
            return r;
        };

        node.consultar = async function (devId) {
            if (!node.sessao) return;
            try {
                const r = await node.sessao.dispositivos([devId]);
                guardarBruto('consulta ' + devId, r);
                const lista = Array.isArray(r.result) ? r.result : r.result && Array.isArray(r.result.devices) ? r.result.devices : [];
                const item = lista.find((x) => (x.id || x.devId) === devId);
                const d = node.dispositivos.get(devId);
                if (!item || !d) return;
                if (item.online !== undefined) d.online = item.online !== false;
                Object.assign(d.status, normalizarStatus(item.status));
            } catch (e) {
                guardarBruto('erro consulta ' + devId, e.message);
            }
        };

        node.on('close', function (feito) {
            node.fechando = true;
            clearTimeout(node.timerMq);
            clearTimeout(node.timerRenovar);
            if (node.mq) node.mq.end(true);
            feito();
        });

        iniciar();
    }

    RED.nodes.registerType('tuya-conta', TuyaConta, {
        credentials: { sessao: { type: 'password' } }
    });

    function limparPendentes() {
        const agora = Date.now();
        for (const [k, v] of pendentes) if (agora - v.criado > 600000) pendentes.delete(k);
    }

    RED.httpAdmin.post('/tuya/login', RED.auth.needsPermission('flows.write'), async (req, res) => {
        try {
            limparPendentes();
            const userCode = String((req.body && req.body.userCode) || '').trim();
            if (!userCode) return res.status(400).json({ erro: 'informe o User Code' });
            const r = await api.gerarQr(userCode);
            if (!r.success) return res.status(502).json({ erro: 'Tuya recusou: ' + (r.msg || JSON.stringify(r).slice(0, 200)) });
            const token = r.result.qrcode;
            const qr = qrcode(0, 'M');
            qr.addData('tuyaSmart--qrLogin?token=' + token);
            qr.make();
            const chave = crypto.randomUUID();
            pendentes.set(chave, { userCode, token, criado: Date.now() });
            res.json({ chave, svg: qr.createSvgTag({ cellSize: 4, margin: 2, scalable: true }) });
        } catch (e) {
            res.status(500).json({ erro: e.message });
        }
    });

    RED.httpAdmin.get('/tuya/login/:chave', RED.auth.needsPermission('flows.write'), async (req, res) => {
        const p = pendentes.get(req.params.chave);
        if (!p) return res.status(404).json({ erro: 'login expirou' });
        try {
            const r = await api.consultarQr(p.token, p.userCode);
            if (!r.success) return res.json({ ok: false });
            pendentes.delete(req.params.chave);
            const sessao = api.sessaoDoLogin(p.userCode, r);
            res.json({ ok: true, sessao: JSON.stringify(sessao.exportar()) });
        } catch (e) {
            res.status(500).json({ erro: e.message });
        }
    });

    RED.httpAdmin.get('/tuya/:id/dispositivos', RED.auth.needsPermission('flows.read'), (req, res) => {
        const conta = RED.nodes.getNode(req.params.id);
        if (!conta || !conta.dispositivos) return res.status(404).json({ erro: 'conta não implantada' });
        res.json({
            estado: conta.estado,
            dispositivos: Array.from(conta.dispositivos.values()).map((d) => ({
                id: d.id,
                nome: d.nome,
                casa: d.casa,
                categoria: d.categoria,
                online: d.online,
                codigos: Object.keys(d.status)
            }))
        });
    });

    RED.httpAdmin.get('/tuya/:id/bruto', RED.auth.needsPermission('flows.read'), (req, res) => {
        const conta = RED.nodes.getNode(req.params.id);
        if (!conta) return res.status(404).json({ erro: 'conta não implantada' });
        res.json(conta.bruto);
    });
};
