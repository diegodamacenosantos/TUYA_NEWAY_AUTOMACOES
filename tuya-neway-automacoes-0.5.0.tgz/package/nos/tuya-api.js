const crypto = require('crypto');

const BASE_LOGIN = 'https://apigw.iotbing.com';
const CLIENT_ID = 'HA_3y9q4ak7g4ephrvke';
const SCHEMA = 'haauthorize';
const ALFABETO = 'ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678';

function md5(texto) {
    return crypto.createHash('md5').update(texto, 'utf8').digest('hex');
}

function hmac(chave, texto) {
    return crypto.createHmac('sha256', chave).update(texto, 'utf8').digest('hex');
}

function sortearNonce() {
    let nonce = '';
    for (let i = 0; i < 12; i++) nonce += ALFABETO[crypto.randomInt(ALFABETO.length)];
    return nonce;
}

function cifrar(segredo, texto) {
    const nonce = sortearNonce();
    const cifra = crypto.createCipheriv('aes-128-gcm', Buffer.from(segredo, 'utf8'), Buffer.from(nonce, 'utf8'));
    const dados = Buffer.concat([cifra.update(texto, 'utf8'), cifra.final(), cifra.getAuthTag()]);
    return Buffer.from(nonce, 'utf8').toString('base64') + dados.toString('base64');
}

function decifrar(segredo, base64) {
    const bruto = Buffer.from(base64, 'base64');
    const nonce = bruto.subarray(0, 12);
    const corpo = bruto.subarray(12, bruto.length - 16);
    const tag = bruto.subarray(bruto.length - 16);
    const decifra = crypto.createDecipheriv('aes-128-gcm', Buffer.from(segredo, 'utf8'), nonce);
    decifra.setAuthTag(tag);
    return Buffer.concat([decifra.update(corpo), decifra.final()]).toString('utf8');
}

function paraQuery(params) {
    return Object.keys(params).map((k) => encodeURIComponent(k) + '=' + encodeURIComponent(params[k])).join('&');
}

async function lerJson(resposta) {
    const texto = await resposta.text();
    try {
        return JSON.parse(texto);
    } catch (e) {
        throw new Error('Resposta invalida (' + resposta.status + '): ' + texto.slice(0, 200));
    }
}

async function gerarQr(userCode) {
    const url = BASE_LOGIN + '/v1.0/m/life/home-assistant/qrcode/tokens?' +
        paraQuery({ clientid: CLIENT_ID, usercode: userCode, schema: SCHEMA });
    return lerJson(await fetch(url, { method: 'POST' }));
}

async function consultarQr(token, userCode) {
    const url = BASE_LOGIN + '/v1.0/m/life/home-assistant/qrcode/tokens/' + encodeURIComponent(token) + '?' +
        paraQuery({ clientid: CLIENT_ID, usercode: userCode });
    return lerJson(await fetch(url));
}

class Sessao {
    constructor(dados) {
        this.endpoint = dados.endpoint;
        this.terminalId = dados.terminalId;
        this.userCode = dados.userCode;
        this.accessToken = dados.accessToken;
        this.refreshToken = dados.refreshToken;
        this.expiraEm = dados.expiraEm;
        this.uid = dados.uid;
        this.aoRenovar = dados.aoRenovar || null;
    }

    exportar() {
        return {
            endpoint: this.endpoint,
            terminalId: this.terminalId,
            userCode: this.userCode,
            accessToken: this.accessToken,
            refreshToken: this.refreshToken,
            expiraEm: this.expiraEm,
            uid: this.uid
        };
    }

    async renovarSeNecessario() {
        if (this.expiraEm - Date.now() > 60000) return;
        const resposta = await this.requisitar('GET', '/v1.0/m/token/' + this.refreshToken, null, null, true);
        if (!resposta.success) throw new Error('Falha ao renovar token: ' + JSON.stringify(resposta));
        const r = resposta.result;
        this.accessToken = r.accessToken;
        this.refreshToken = r.refreshToken;
        this.uid = r.uid || this.uid;
        this.expiraEm = resposta.t + r.expireTime * 1000;
        if (this.aoRenovar) this.aoRenovar(this.exportar());
    }

    async requisitar(metodo, caminho, params, corpo, semRenovar) {
        if (!semRenovar) await this.renovarSeNecessario();
        const rid = crypto.randomUUID();
        const hashKey = md5(rid + this.refreshToken);
        const segredo = hmac(rid, hashKey).slice(0, 16);
        const cabecalhos = {
            'X-appKey': CLIENT_ID,
            'X-requestId': rid,
            'X-sid': '',
            'X-time': String(Date.now())
        };
        if (this.accessToken && !semRenovar) cabecalhos['X-token'] = this.accessToken;
        const queryEnc = params && Object.keys(params).length ? cifrar(segredo, JSON.stringify(params)) : '';
        const corpoEnc = corpo && Object.keys(corpo).length ? cifrar(segredo, JSON.stringify(corpo)) : '';
        const partes = ['X-appKey', 'X-requestId', 'X-sid', 'X-time', 'X-token']
            .filter((k) => cabecalhos[k])
            .map((k) => k + '=' + cabecalhos[k]);
        const assinar = partes.join('||') + queryEnc + corpoEnc;
        cabecalhos['X-sign'] = hmac(hashKey, assinar);
        let url = this.endpoint + caminho;
        if (queryEnc) url += '?' + paraQuery({ encdata: queryEnc });
        const opcoes = { method: metodo, headers: cabecalhos };
        if (corpoEnc) {
            opcoes.headers['Content-Type'] = 'application/json';
            opcoes.body = JSON.stringify({ encdata: corpoEnc });
        }
        const resposta = await lerJson(await fetch(url, opcoes));
        if (typeof resposta.result === 'string') {
            try {
                const aberto = decifrar(segredo, resposta.result);
                try {
                    resposta.result = JSON.parse(aberto);
                } catch (e) {
                    resposta.result = aberto;
                }
            } catch (e) {}
        }
        return resposta;
    }

    casas() {
        return this.requisitar('GET', '/v1.0/m/life/users/homes');
    }

    dispositivosDaCasa(homeId) {
        return this.requisitar('GET', '/v1.0/m/life/ha/home/devices', { homeId: String(homeId) });
    }

    dispositivos(ids) {
        return this.requisitar('GET', '/v1.0/m/life/ha/devices/detail', { devIds: ids.join(',') });
    }

    especificacao(id) {
        return this.requisitar('GET', '/v1.1/m/life/' + id + '/specifications');
    }

    comando(id, comandos) {
        return this.requisitar('POST', '/v1.1/m/thing/' + id + '/commands', null, { commands: comandos });
    }

    configMq() {
        return this.requisitar('POST', '/v1.0/m/life/ha/access/config', null, {
            linkId: 'tuya-device-sharing-sdk-python.' + crypto.randomUUID()
        });
    }
}

function sessaoDoLogin(userCode, resposta) {
    const r = resposta.result;
    return new Sessao({
        userCode,
        endpoint: r.endpoint,
        terminalId: r.terminal_id,
        accessToken: r.access_token,
        refreshToken: r.refresh_token,
        uid: r.uid,
        expiraEm: (resposta.t || Date.now()) + r.expire_time * 1000
    });
}

module.exports = { CLIENT_ID, gerarQr, consultarQr, sessaoDoLogin, Sessao, cifrar, decifrar };
